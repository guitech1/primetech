Prime Tech - versão editada

O que foi adicionado:
- Painel ADM aparece para is_admin = true.
- Rastreio no modelo roxo/preto enviado por você.
- Rastreio lendo a tabela public.tracking do Supabase.
- Produtos com botões Comprar e Carrinho.
- Clique na foto abre página completa do produto.
- Checkout com formulário de entrega.
- CEP automático usando ViaCEP.
- Telefone obrigatório na entrega.
- Frete R$7,82 quando existir produto abaixo de R$100.
- Pagamento Pix em área separada estilo maquininha.
- Endereço/telefone ficam salvos no pedido para você ver no Painel ADM.
- Foto de perfil por arquivo do PC/celular no bucket avatars.

Antes de publicar, rode no Supabase:
prime-tech-edicoes-sql.sql

Depois publique o index.html na Netlify.
