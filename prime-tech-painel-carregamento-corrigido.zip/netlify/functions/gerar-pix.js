exports.handler = async function (event) {
  const headers = { "Content-Type": "application/json" };
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Método não permitido" }) };
  }

  try {
    const { nome, valor, descricao, pedido_id } = JSON.parse(event.body || "{}");

    if (!process.env.JUMPFY_API_KEY) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "JUMPFY_API_KEY não configurada na Netlify" }) };
    }

    const resposta = await fetch("https://jumpfy.io/api/pix/create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.JUMPFY_API_KEY
      },
      body: JSON.stringify({
        amount: Number(valor),
        description: descricao || `Pedido Prime Tech - ${nome || "Cliente"}`,
        external_id: String(pedido_id || ("prime_" + Date.now())),
        expiration: 1800
      })
    });

    const texto = await resposta.text();
    let dados;
    try { dados = JSON.parse(texto); }
    catch (e) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "Jumpfy não retornou JSON", resposta: texto }) };
    }

    if (!resposta.ok) {
      return { statusCode: resposta.status, headers, body: JSON.stringify({ error: dados.message || dados.error || dados.erro || "Erro na Jumpfy", detalhes: dados }) };
    }

    const t = dados.transaction || dados;
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        pix_copia_cola: t.pix_copia_cola || t.pix_copy_paste || t.copy_paste || t.qr_code || "",
        qr_code_base64: t.qr_code_base64 || t.qrcode_base64 || "",
        status: t.status || dados.status || "created",
        id: t.id || dados.id || null,
        original: dados
      })
    };
  } catch (erro) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: erro.message || "Erro interno" }) };
  }
};
