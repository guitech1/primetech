PRIME TECH 🇧🇷 — pacote conectado ao Supabase

Arquivos:
- index.html
- netlify.toml
- netlify/functions/gerar-pix.js
- prime-tech-politicas-extras.sql

Antes de publicar:
1. Rode prime-tech-politicas-extras.sql no SQL Editor do Supabase.
2. Faça uma conta pelo site.
3. No Supabase, rode:
   update public.users set is_admin = true where email = 'SEU_EMAIL_AQUI';
4. Na Netlify, adicione a variável de ambiente:
   JUMPFY_API_KEY = sua chave da Jumpfy
5. Publique o projeto.

Observação:
- A anon key do Supabase é pública por natureza.
- Nunca coloque service_role no HTML.
